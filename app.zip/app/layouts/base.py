def create_base_layout(content):
    return {
        'content': content  # Ahora devuelve un diccionario con la clave 'content'
    }